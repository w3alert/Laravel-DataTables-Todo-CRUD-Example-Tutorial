<!doctype html>
<html lang="en">
  <head>
  <meta charset="utf-8">

  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <meta name="csrf-token" content="{{ csrf_token() }}">

  <title>Laravel Update Todo Example Tutorial- w3alert.com</title>

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" />

</head>
 
<body>
 
<div class="container mt-5">
   
    <form id="add-todo" method="post" action="{{ url('update-todo') }}"> 
      @csrf
      
      <input type="hidden" name="id" class="form-control" value="{{ $todo->id }}" id="formGroupExampleInput">

      <div class="form-group">
        <label for="formGroupExampleInput">Title</label>
        <input type="text" name="title" class="form-control" id="formGroupExampleInput" placeholder="Please enter title" value="{{ $todo->title }}">
        <span class="text-danger">{{ $errors->first('title') }}</span>
      </div> 

      <div class="form-group">
        <label for="message">Description</label>
        <textarea name="description" class="form-control" id="description" placeholder="Please enter description">{{ $todo->description }}</textarea>
        <span class="text-danger">{{ $errors->first('description') }}</span>
      </div>

      <div class="form-group">
       <button type="submit" class="btn btn-success" id="btn-send">Submit</button>
      </div>
    </form>
 
</div>
</body>
</html>