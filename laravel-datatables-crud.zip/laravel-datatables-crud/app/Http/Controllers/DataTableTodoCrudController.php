<?php
 
namespace App\Http\Controllers;
 
use Illuminate\Http\Request;
use Validator,Redirect,Response;
Use App\Todo;
 
class DataTableTodoCrudController extends Controller
{
   /* Display todo list */

    public function index() 
    {
        if(request()->ajax()) {
            return datatables()->of(Todo::select([
                'id','title' , 'description', 'created_at'
            ]))
            ->addIndexColumn()
            ->addColumn('action', function($data){
                   
                   $editUrl = url('edit-todo/'.$data->id);
                   $btn = '<a href="'.$editUrl.'" data-toggle="tooltip" data-original-title="Edit" class="edit btn btn-primary btn-sm">Edit</a>';

                   $btn = $btn.' <a href="javascript:void(0)" data-toggle="tooltip"  data-id="'.$data->id.'" data-original-title="Delete" class="btn btn-danger btn-sm deleteTodo">Delete</a>';

                    return $btn;
            })
            ->rawColumns(['action'])
            ->make(true);
        }
        return view('list-todo');
    }
    
    /* Display todo add form */

    public function create()
    {
      return view('add-todo');
    }
    
    /* insert todo list into mysql database*/

    public function store(Request $request)
    {
        $data = request()->validate([
        'title' => 'required',
        'description' => 'required',
        ]);
       
        $check = Todo::create($data);
        return Redirect::to("list")->withSuccess('Great! Todo has been inserted');
    }

    /* display edit todo form with data */

    public function edit(Request $request, $id)
    {
       
        $data['todo'] = Todo::where('id', $id)->first();

        if(!$data['todo']){
           return redirect('/list');
        }
        return view('edit-todo', $data);
    }
    
    /* update todo into mysql database */

    public function update(Request $request)
    {
        $data = request()->validate([
        'title' => 'required',
        'description' => 'required',
        ]);
       
        if(!$request->id){
           return redirect('/list');
        }

        $check = todo::where('id', $request->id)->update($data);
        return Redirect::to("list")->withSuccess('Great! Todo has been updated');
    }  

    /* delete todo from mysql database */

    public function delete(Request $request, $id)
    {
        $check = Todo::where('id', $id)->delete();
 
        return Response::json($check);
    }

}