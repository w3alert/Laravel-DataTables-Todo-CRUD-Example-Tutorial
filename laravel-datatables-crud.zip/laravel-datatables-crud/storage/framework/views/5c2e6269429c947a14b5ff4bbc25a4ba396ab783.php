<!doctype html>
<html lang="en">
  <head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <title>Laravel Jquery Form Validation Example - Tutsmake.com</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" />
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>  
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.js"></script>  
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/additional-methods.min.js"></script>
  <style>
   .error{ color:red; } 
  </style>
</head>
 
<body>
 
<div class="container mt-5">
   
    <form id="contact-us-form" method="post" action="javascript:void(0)">
      <?php echo csrf_field(); ?>

      <div class="form-group">
        <label for="formGroupExampleInput">Name</label>
        <input type="text" name="name" class="form-control" id="formGroupExampleInput" placeholder="Please enter name">
        <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
      </div>

      <div class="form-group">
        <label for="email">Email Id</label>
        <input type="text" name="email" class="form-control" id="email" placeholder="Please enter email id">
        <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
      </div>  

      <div class="form-group">
        <label for="message">Message</label>
        <textarea name="message" class="form-control" id="message" placeholder="Please enter message"></textarea>
        <span class="text-danger"><?php echo e($errors->first('message')); ?></span>
      </div>

      <div class="form-group">
       <button type="submit" class="btn btn-success" id="btn-send">Submit</button>
      </div>
    </form>
 
</div>
<script>
   if ($("#contact-us-form").length > 0) {
    $("#contact-us-form").validate({
     
    rules: {
      name: {
        required: true,
        maxlength: 50
      },
 
      email: {
        required: true,
        maxlength: 50,
        email: true,
      },  

      message: {
        required: true,
        minlength: 50,
        maxlength: 200,
      },    
    },
    messages: {
       
      name: {
        required: "Please enter name",
        maxlength: "Your last name maxlength should be 50 characters long."
      },

      email: {
          required: "Please enter valid email",
          email: "Please enter valid email",
          maxlength: "The email name should less than or equal to 50 characters",
      },      

      message: {
          required: "Please enter message",
          minlength: "The message should be accept minimum 50 characters",
          maxlength: "The message should be accept minimum 50 characters",
      },
        
    },
    submitHandler: function(form) {
     $.ajaxSetup({
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
      });

      $('#btn-send').html('Sending..');

      $.ajax({
        url: 'http://localhost/FormValidation/public/save-contact' ,
        type: "POST",
        data: $('#contact-us-form').serialize(),
        success: (response) => {
            this.reset();
            alert(response.msg);
            $("#contact-us-form")[0].reset();
            $('#btn-send').html('Submit');
        },
        error: function(response){
            console.log(response);
        }
      });
    },

   })
  }
</script>
</body>
</html><?php /**PATH D:\xampp\htdocs\FormValidation\resources\views/contact.blade.php ENDPATH**/ ?>