<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

//display todo list
Route::get('list','DataTableTodoCrudController@index');

//display add todo form and create a new todo
Route::get('add-todo','DataTableTodoCrudController@create');
Route::post('post-todo','DataTableTodoCrudController@store');

//display add todo form and create a new todo
Route::get('edit-todo/{id?}','DataTableTodoCrudController@edit');
Route::post('update-todo','DataTableTodoCrudController@update');

//display add todo form and create a new todo
Route::get('delete-todo/{id?}','DataTableTodoCrudController@delete');